package com.example.branchcustomer.data.model

data class AppResource<out T>(val status: Status, val data : T?, val msg : String?) {

    companion object{
        fun <T> success(data : T?) = AppResource(Status.SUCCESS,data,null)
        fun <T> error(data : T?,msg : String) = AppResource(Status.ERROR,data,msg)
        fun loading() = AppResource(Status.LOADING,null,null)
    }

}