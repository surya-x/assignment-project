package com.example.branchcustomer.presentation.activity

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.branchcustomer.utils.MyViewModelFactory
import com.example.branchcustomer.R
import com.example.branchcustomer.data.model.Status
import com.example.branchcustomer.databinding.ActivityMainBinding
import com.example.branchcustomer.presentation.fragment.HomeFragment
import com.example.branchcustomer.presentation.viewmodel.MainViewModel


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel

    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, MyViewModelFactory(this.applicationContext))[MainViewModel::class.java]

        viewModel.toolbarTitle.value = getString(R.string.app_name)
        setupList()
        setupListener()
    }

    private fun setupListener() {
        viewModel.toolbarTitle.observe(this){
            binding.tvTitle.text = it
        }
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.ivMore.setOnClickListener {
            showLogoutDialog()
        }
    }

    private fun showLogoutDialog() {
        val colors = arrayOf("Yes", "No")
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Logout")
        builder.setItems(colors, DialogInterface.OnClickListener { dialog, which ->
            dialog.dismiss()
            if (which == 0) {
                logout()
            }
        })
        builder.show()
    }

    private fun logout() {
        viewModel.logoutUser()

        val intent = Intent(this, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }

    private fun setupList() {

        binding.progressBar.visibility = View.VISIBLE

        viewModel.fetchAllMessages(this).observe(this) {
            when (it.status) {
                Status.SUCCESS -> {
                    viewModel.allMessages.addAll(it.data!!)
                    binding.progressBar.visibility = View.GONE
                    supportFragmentManager.beginTransaction().replace(binding.frameLayout.id, HomeFragment()).commit()
                }
                Status.ERROR -> {
                    Toast.makeText(this, it.msg, Toast.LENGTH_SHORT).show()
                    binding.progressBar.visibility = View.GONE
                }
            }
        }
    }

}