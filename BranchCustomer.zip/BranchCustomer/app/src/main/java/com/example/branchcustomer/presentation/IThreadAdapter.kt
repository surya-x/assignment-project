package com.example.branchcustomer.presentation

import com.example.branchcustomer.data.model.Message

interface IThreadAdapter {
    fun onItemClicked(conversationThread: Message)
}