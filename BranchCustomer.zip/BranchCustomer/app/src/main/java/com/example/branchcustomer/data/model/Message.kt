package com.example.branchcustomer.data.model

import android.R.string
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
import java.util.Collections.replaceAll


data class Message(

    @field:SerializedName("thread_id")
    val threadId: Int? = null,

    @field:SerializedName("agent_id")
    val agentId: Any? = null,

    @field:SerializedName("user_id")
    val userId: String? = null,

    @field:SerializedName("id")
    val id: Int? = null,

    @field:SerializedName("body")
    val body: String? = null,

    @field:SerializedName("timestamp")
    val timestamp: String? = null

) : Comparable<Message> {
    override fun compareTo(other: Message): Int {
        // If this.timestamp is most recent return +ve number

        val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm'Z'")
        val myDate: Date = format.parse(this.timestamp)
        val otherDate: Date = format.parse(other.timestamp)

        return myDate.compareTo(otherDate)
//        return if (myDate > otherDate) 1
//        else if (myDate < otherDate) -1
//        else 0
    }
}
