package com.example.branchcustomer.presentation.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.branchcustomer.data.PreferenceUtility
import com.example.branchcustomer.data.RepositoryImpl
import com.example.branchcustomer.data.model.AppResource
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.data.model.SendMessageRequest
import com.example.branchcustomer.domain.Repository
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class MainViewModel(private val repo: Repository, private val preferenceUtility: PreferenceUtility) : ViewModel() {

    val allMessages = ArrayList<Message>()
    val uniqueThreadsSorted = MutableLiveData<ArrayList<Message>>()
    val mapOfUniqueThreads = HashMap<Int, ArrayList<Message>>()  // <Thread, ListOfMessages that belong to the thread>

    var currentThreadId: Int = -1
    var isDataLoaded = false

    val toolbarTitle = MutableLiveData<String>()

    fun fetchAllMessages(context: Context) : LiveData<AppResource<ArrayList<Message>>> {
        val allMessagesLiveData : MutableLiveData<AppResource<ArrayList<Message>>> = MutableLiveData()
        repo.getAllMessages(context, preferenceUtility.getToken()!!, allMessagesLiveData)
        return allMessagesLiveData
    }

    fun showUniqueThreads() {
        isDataLoaded = true
        createMapOfThreads()
    }

    private fun createMapOfThreads() {
        for (msg in allMessages) {
            val threadId = msg.threadId ?: continue

            if (mapOfUniqueThreads.containsKey(threadId)) {
                mapOfUniqueThreads[threadId]?.add(msg)
            } else {
                val tempList = ArrayList<Message>()
                tempList.add(msg)
                mapOfUniqueThreads[threadId] = tempList
            }
        }

        createListOfThreads(toSort = true)
    }

    fun createListOfThreads(toSort: Boolean) {
        val latestMessageOfEachThread = ArrayList<Message>()

        // Sorting List of messages for each Thread
        for (list in mapOfUniqueThreads.values) {
            if (list.isNotEmpty()) {
                if (toSort)
                    list.sort()
                latestMessageOfEachThread.add(list.last())
            }
        }

        latestMessageOfEachThread.sort()
        latestMessageOfEachThread.reverse()
        uniqueThreadsSorted.value = latestMessageOfEachThread
    }

    fun sendMessage(context: Context, inputText: String) : LiveData<AppResource<Message>>{
        val messageLiveData : MutableLiveData<AppResource<Message>> = MutableLiveData()
        val requestBody = SendMessageRequest(
            threadId = currentThreadId,
            body = inputText
        )
        repo.sendMessage(context, preferenceUtility.getToken()!!, requestBody, messageLiveData)
        return messageLiveData
    }

    fun addNewlySentMessageToList(message: Message) {
        allMessages.add(message)
        mapOfUniqueThreads[currentThreadId]?.add(message)
    }

    fun logoutUser() {
        preferenceUtility.resetToken()
    }
}