package com.example.branchcustomer.presentation.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.branchcustomer.R
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.utils.FormatTime
import com.google.android.material.card.MaterialCardView
import java.text.SimpleDateFormat
import java.util.*

class ConversationAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val VIEW_TYPE_MESSAGE_SENT = 1
    private val VIEW_TYPE_MESSAGE_RECEIVED = 2

    private val dataSet = ArrayList<Message>()

    private class ReceivedMessageHolder(view: View) : RecyclerView.ViewHolder(view) {

        val userId: TextView = view.findViewById(R.id.user_id)
        val body: TextView = view.findViewById(R.id.message_body)
        val timestamp: TextView = view.findViewById(R.id.timestamp)

        fun bind(message: Message) {
            userId.text = message.userId
            body.text = message.body
            timestamp.text = FormatTime().getReadableTimeFromTimestamp(message.timestamp)
        }
    }

    private class SentMessageHolder(view: View) : RecyclerView.ViewHolder(view) {

        val body: TextView = view.findViewById(R.id.message_body)
        val timestamp: TextView = view.findViewById(R.id.timestamp)

        fun bind(message: Message) {
            body.text = message.body
            timestamp.text = FormatTime().getReadableTimeFromTimestamp(message.timestamp)
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            val viewHolder = ReceivedMessageHolder(
                LayoutInflater.from(viewGroup.context)
                    .inflate(R.layout.message_left_item, viewGroup, false)
            )
            viewHolder
        } else  {
            val viewHolder = SentMessageHolder(
                LayoutInflater.from(viewGroup.context)
                    .inflate(R.layout.message_right_item, viewGroup, false)
            )
            viewHolder
        }
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {

        val message = dataSet[position]

        if (viewHolder.itemViewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            (viewHolder as ReceivedMessageHolder).bind(message)
        } else {
            (viewHolder as SentMessageHolder).bind(message)
        }
    }

    override fun getItemCount() = dataSet.size

    override fun getItemViewType(position: Int): Int {
        return if (dataSet[position].agentId != null){
            VIEW_TYPE_MESSAGE_SENT
        } else {
            VIEW_TYPE_MESSAGE_RECEIVED
        }
    }

    fun updateDataSet(newDataSet: List<Message>) {
        dataSet.clear()
        dataSet.addAll(newDataSet)
        notifyDataSetChanged()
    }
}

