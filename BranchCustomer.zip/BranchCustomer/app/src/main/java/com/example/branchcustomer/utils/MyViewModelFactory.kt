package com.example.branchcustomer.utils

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.branchcustomer.data.BranchApiManager
import com.example.branchcustomer.data.PreferenceUtility
import com.example.branchcustomer.data.RepositoryImpl
import com.example.branchcustomer.presentation.viewmodel.LoginViewModel
import com.example.branchcustomer.presentation.viewmodel.MainViewModel


class MyViewModelFactory(private val context: Context) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java))
            return MainViewModel(RepositoryImpl(BranchApiManager()), PreferenceUtility(context)) as T
        else if (modelClass.isAssignableFrom(LoginViewModel::class.java))
            return LoginViewModel(RepositoryImpl(BranchApiManager()), PreferenceUtility(context)) as T
        else
            throw IllegalArgumentException("Unknown ViewModel class");
    }
}