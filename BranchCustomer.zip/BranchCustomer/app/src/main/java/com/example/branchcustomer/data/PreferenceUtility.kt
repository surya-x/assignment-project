package com.example.branchcustomer.data

import android.content.Context
import android.content.Context.MODE_PRIVATE

import android.content.SharedPreferences


class PreferenceUtility(context: Context) {

    var sharedPreferences: SharedPreferences =
        context.getSharedPreferences("branch_preference", MODE_PRIVATE)

    private val editor = sharedPreferences.edit()
    private val auth_key = "auth_token"

    fun getToken(): String? {
        return sharedPreferences.getString(auth_key, "")
    }

    fun setToken(auth_token: String) {
        editor.putString(auth_key, auth_token)
        editor.commit()
    }

    fun resetToken() {
        editor.putString(auth_key, "")
        editor.commit()
    }

}