package com.example.branchcustomer.data

import com.example.branchcustomer.data.model.AuthUserRequest
import com.example.branchcustomer.data.model.AuthUserResponse
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.data.model.SendMessageRequest
import com.example.branchcustomer.domain.BranchAPIBuilder
import com.example.branchcustomer.domain.RestAPI
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BranchApiManager {

    private val retrofit = BranchAPIBuilder.buildService(RestAPI::class.java)

    fun addUser(requestData: AuthUserRequest, onResult: (AuthUserResponse?) -> Unit){
        retrofit.addUser(requestData).enqueue(
            object : Callback<AuthUserResponse> {
                override fun onFailure(call: Call<AuthUserResponse>, t: Throwable) {
                    onResult(null)
                }
                override fun onResponse(call: Call<AuthUserResponse>, response: Response<AuthUserResponse>) {
                    val addedUser = response.body()
                    onResult(addedUser)
                }
            }
        )
    }

    fun getAllMessages(authToken: String, onResult: (ArrayList<Message>?) -> Unit){
        retrofit.getAllMessages(authToken).enqueue(
            object : Callback<ArrayList<Message>> {
                override fun onFailure(call: Call<ArrayList<Message>>, t: Throwable) {
                    onResult(null)
                }
                override fun onResponse(
                    call: Call<ArrayList<Message>>,
                    response: Response<ArrayList<Message>>
                ) {
                    onResult(response.body())
                }
            }
        )
    }

    fun sendMessage(authToken: String, request: SendMessageRequest, onResult: (Message?) -> Unit){
        retrofit.sendMessage(authToken, request).enqueue(
            object : Callback<Message> {
                override fun onResponse(call: Call<Message>, response: Response<Message>) {
                    onResult(response.body())
                }
                override fun onFailure(call: Call<Message>, t: Throwable) {
                    onResult(null)
                }

            }
        )
    }

}

