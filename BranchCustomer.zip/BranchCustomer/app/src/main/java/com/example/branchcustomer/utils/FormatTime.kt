package com.example.branchcustomer.utils

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.*

class FormatTime {
    private val oldFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private val newFormat = SimpleDateFormat("yyyy-MM-dd HH:mm")

    /**
     * To get showable time & date from timestamp
     */
    fun getReadableTimeFromTimestamp(timestamp: String?) : String {
        if (timestamp.isNullOrBlank())
            return ""

        val date: Date = oldFormat.parse(timestamp)
        return newFormat.format(date)
    }
}