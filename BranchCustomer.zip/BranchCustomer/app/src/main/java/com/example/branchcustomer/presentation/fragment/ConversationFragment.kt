package com.example.branchcustomer.presentation.fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.branchcustomer.R
import com.example.branchcustomer.data.model.Status
import com.example.branchcustomer.databinding.FragmentConversationBinding
import com.example.branchcustomer.presentation.adapter.ConversationAdapter
import com.example.branchcustomer.presentation.adapter.ThreadAdapter
import com.example.branchcustomer.presentation.viewmodel.MainViewModel

class ConversationFragment : Fragment() {

    private lateinit var binding: FragmentConversationBinding
    private lateinit var adapter: ConversationAdapter
    private val viewModel: MainViewModel by activityViewModels()

    private val TAG = "ConversationFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentConversationBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = ConversationAdapter()
        binding.recyclerView.adapter = adapter

        viewModel.toolbarTitle.value = viewModel.mapOfUniqueThreads[viewModel.currentThreadId]?.first()?.userId

        setupList()
        setupListener()
    }

    private fun setupListener() {
        binding.ivSend.setOnClickListener {
            if (binding.edittextDialogueInput.text.isNotEmpty()){
                sendMessage(binding.edittextDialogueInput.text.toString())
            } else {
                binding.edittextDialogueInput.error = requireContext().getString(R.string.text_cant_be_empty)
            }
        }
    }

    private fun sendMessage(text: String) {
        viewModel.sendMessage(requireContext(), text).observe(viewLifecycleOwner) {
            when (it.status) {
                Status.SUCCESS -> {
                    Toast.makeText(requireContext(), "Message sent", Toast.LENGTH_SHORT).show()
                    binding.edittextDialogueInput.text.clear()

                    viewModel.addNewlySentMessageToList(it.data!!)
                    setupList()
                }
                Status.ERROR -> {
                    Toast.makeText(requireContext(), it.msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupList() {
        adapter.updateDataSet(viewModel.mapOfUniqueThreads[viewModel.currentThreadId]!!)
    }
}