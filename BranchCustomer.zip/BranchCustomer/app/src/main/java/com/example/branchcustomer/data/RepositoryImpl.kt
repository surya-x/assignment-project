package com.example.branchcustomer.data

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.example.branchcustomer.R
import com.example.branchcustomer.data.model.*
import com.example.branchcustomer.domain.Repository

class RepositoryImpl (private val apiService: BranchApiManager) : Repository {

    override fun signInWithEmailAndPassword(mContext: Context, userInfo: AuthUserRequest, loginLiveData : MutableLiveData<AppResource<AuthUserResponse>>) {

        apiService.addUser(userInfo) {
            if (it?.authToken != null) {
                loginLiveData.postValue(AppResource.success(it))
            } else {
                loginLiveData.postValue(AppResource.error(null, mContext.getString(R.string.unable_to_login)))
            }
        }
    }

    override fun getAllMessages(mContext: Context, authToken: String, messageLiveData : MutableLiveData<AppResource<ArrayList<Message>>>) {

        apiService.getAllMessages(authToken) {
            if (it != null) {
                messageLiveData.postValue(AppResource.success(it))
            } else {
                messageLiveData.postValue(AppResource.error(null, mContext.getString(R.string.unable_to_load_messages)))
            }
        }
    }

    override fun sendMessage(mContext: Context, authToken: String, request: SendMessageRequest, messageLiveData : MutableLiveData<AppResource<Message>>) {

        apiService.sendMessage(authToken, request) {
            if (it != null) {
                messageLiveData.postValue(AppResource.success(it))
            } else {
                messageLiveData.postValue(AppResource.error(null, mContext.getString(R.string.unable_to_send_messages)))
            }
        }
    }
}