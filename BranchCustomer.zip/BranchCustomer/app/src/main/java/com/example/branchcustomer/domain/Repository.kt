package com.example.branchcustomer.domain

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.example.branchcustomer.data.model.*

interface Repository {
    fun signInWithEmailAndPassword(
        mContext: Context,
        userInfo: AuthUserRequest,
        loginLiveData: MutableLiveData<AppResource<AuthUserResponse>>
    )

    fun getAllMessages(
        mContext: Context,
        authToken: String,
        messageLiveData: MutableLiveData<AppResource<ArrayList<Message>>>
    )

    fun sendMessage(
        mContext: Context,
        authToken: String,
        request: SendMessageRequest,
        messageLiveData: MutableLiveData<AppResource<Message>>
    )
}