package com.example.branchcustomer.presentation.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.branchcustomer.R
import com.example.branchcustomer.presentation.adapter.ThreadAdapter
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.databinding.FragmentHomeBinding
import com.example.branchcustomer.presentation.IThreadAdapter
import com.example.branchcustomer.presentation.viewmodel.MainViewModel

class HomeFragment : Fragment(), IThreadAdapter {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var adapter: ThreadAdapter
    private val viewModel: MainViewModel by activityViewModels()

    private val TAG = "HomeFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = ThreadAdapter(this)
        binding.recyclerView.adapter = adapter

        viewModel.toolbarTitle.value = getString(R.string.app_name)

        setupObserver()

        if (!viewModel.isDataLoaded)
            viewModel.showUniqueThreads()
        else
            viewModel.createListOfThreads(false)
    }

    private fun setupObserver() {
        viewModel.uniqueThreadsSorted.observe(viewLifecycleOwner) {
            adapter.updateDataSet(it)
        }
    }

    override fun onItemClicked(conversationThread: Message) {
        conversationThread.threadId?.let { viewModel.currentThreadId = conversationThread.threadId }
        parentFragmentManager
            .beginTransaction()
            .replace(R.id.frame_layout, ConversationFragment())
            .addToBackStack("fragment")
            .commit()
    }

}