package com.example.branchcustomer.data.model

import com.google.gson.annotations.SerializedName

data class AuthUserResponse(
    @SerializedName("auth_token") val authToken: String
)
