package com.example.branchcustomer.data.model

import com.google.gson.annotations.SerializedName

data class SendMessageRequest(
    @SerializedName("thread_id") val threadId: Int,
    @SerializedName("body") val body: String,
)
