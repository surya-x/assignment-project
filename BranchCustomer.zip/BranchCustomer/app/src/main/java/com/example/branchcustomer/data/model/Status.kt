package com.example.branchcustomer.data.model

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}