package com.example.branchcustomer.presentation.viewmodel

import android.content.Context
import android.util.Log
import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.branchcustomer.data.model.AuthUserResponse
import com.example.branchcustomer.R
import com.example.branchcustomer.data.PreferenceUtility
import com.example.branchcustomer.data.RepositoryImpl
import com.example.branchcustomer.data.model.AppResource
import com.example.branchcustomer.data.model.AuthUserRequest
import com.example.branchcustomer.domain.Repository

class LoginViewModel(private val repo: Repository, private val preferenceUtility: PreferenceUtility) : ViewModel() {

    private val TAG = "LoginViewModel"

    var email: String = ""
    var password: String = ""

    private val _emailError = MutableLiveData<String>()
    val emailError: LiveData<String>
        get() = _emailError

    private val _passwordError = MutableLiveData<String>()
    val passwordError: LiveData<String>
        get() = _passwordError

    fun isValidInput(context: Context) : Boolean{
        email = email.trim()
        return when {
            email.isEmpty() -> {
                Log.d(TAG, "email is empty")
                _emailError.value = context.getString(R.string.malformed_email_empty_error)
                false
            }
            password.isEmpty() -> {
                Log.d(TAG, "email is empty")
                _passwordError.value = context.getString(R.string.malformed_password_empty_error)
                false
            }

            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                Log.d(TAG, "email pattern mismatched")
                _emailError.value = context.getString(R.string.malformed_email_error)
                false
            }

            else -> {
                Log.d(TAG, "isValidInput: returning true")
                true
            }
        }
    }

    fun login(context: Context) : LiveData<AppResource<AuthUserResponse>> {
        val loginLiveData : MutableLiveData<AppResource<AuthUserResponse>> = MutableLiveData()

        val userInfo = AuthUserRequest(email, password)
        repo.signInWithEmailAndPassword(context, userInfo, loginLiveData)
        return loginLiveData
    }

    fun addTokenToPref(authToken: String) {
        preferenceUtility.setToken(authToken)
    }

    fun isAlreadyLoggedInUser(): Boolean {
        val token = preferenceUtility.getToken()
        if(token != null && token.isNotEmpty()){
            return true
        }
        return false
    }
}