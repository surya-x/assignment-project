package com.example.branchcustomer.presentation.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.ViewModelProvider
import com.example.branchcustomer.utils.MyViewModelFactory
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.data.model.Status
import com.example.branchcustomer.databinding.ActivityLoginBinding
import com.example.branchcustomer.presentation.viewmodel.LoginViewModel


class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var viewModel: LoginViewModel

    private val TAG = "LoginActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, MyViewModelFactory(this.applicationContext))[LoginViewModel::class.java]

        if (viewModel.isAlreadyLoggedInUser()){
            loadMainActivity()
        }

        setupListeners()
        setupObserver()

        /* FOR TESTING PURPOSE */
//        binding.login.setOnClickListener {
//            addTestUser()
//        }
    }

    private fun setupListeners() {
        binding.email.doAfterTextChanged { email -> viewModel.email = email.toString() }
        binding.password.doAfterTextChanged { pass -> viewModel.password = pass.toString() }

        binding.login.setOnClickListener {
            if (viewModel.isValidInput(this)) {
                login()
            }
        }
    }

    private fun setupObserver() {
        viewModel.emailError.observe(this) {
            if (it.isNotEmpty()) {
                binding.email.error = it
            }
        }
        viewModel.passwordError.observe(this) {
            if (it.isNotEmpty()) {
                binding.password.error = it
            }
        }
    }

    private fun login() {
        binding.progressBar.visibility = View.VISIBLE

        viewModel.login(this).observe(this) {
            when (it.status) {
                Status.SUCCESS -> {
                    viewModel.addTokenToPref(it.data!!.authToken)
                    loadMainActivity()
                }
                Status.ERROR -> {
                    Toast.makeText(this, it.msg, Toast.LENGTH_SHORT).show()
                    binding.progressBar.visibility = View.GONE
                }
                Status.LOADING -> {}
            }
        }
    }

    private fun loadMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }

    /**
     * FOR TESTING PURPOSE
     */
//    private fun addTestUser() {
//        viewModel.email = "kumarsurya.2001@gmail.com"
//        viewModel.password = "moc.liamg@1002.ayrusramuk"
//
//        login()
//    }
}