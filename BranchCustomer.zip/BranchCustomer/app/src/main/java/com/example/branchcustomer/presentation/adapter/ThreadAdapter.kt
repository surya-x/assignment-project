package com.example.branchcustomer.presentation.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.branchcustomer.R
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.presentation.IThreadAdapter
import com.example.branchcustomer.utils.FormatTime
import com.google.android.material.card.MaterialCardView
import java.text.SimpleDateFormat
import java.util.*

class ThreadAdapter(private val listener: IThreadAdapter) :
    RecyclerView.Adapter<ThreadAdapter.ViewHolder>() {

    private val dataSet = ArrayList<Message>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardView: MaterialCardView = view.findViewById(R.id.thread_card_item)
        val userId: TextView = view.findViewById(R.id.user_id)
        val body: TextView = view.findViewById(R.id.body)
        val timestamp: TextView = view.findViewById(R.id.timestamp)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val viewHolder = ViewHolder(LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.item_thread, viewGroup, false))

        viewHolder.cardView.setOnClickListener { listener.onItemClicked(dataSet[viewHolder.adapterPosition]) }
        return viewHolder
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.userId.text = dataSet[position].userId
        viewHolder.body.text = dataSet[position].body

        viewHolder.timestamp.text = FormatTime().getReadableTimeFromTimestamp(dataSet[position].timestamp)
    }

    override fun getItemCount() = dataSet.size

    fun updateDataSet(newDataSet: List<Message>){
        dataSet.clear()
        dataSet.addAll(newDataSet)
        notifyDataSetChanged()
    }
}

