package com.example.branchcustomer.domain

import retrofit2.Call
import com.example.branchcustomer.data.model.AuthUserRequest
import com.example.branchcustomer.data.model.AuthUserResponse
import com.example.branchcustomer.data.model.Message
import com.example.branchcustomer.data.model.SendMessageRequest
import retrofit2.http.*

interface RestAPI {
    @Headers("Content-Type: application/json")
    @POST("api/login")
    fun addUser(@Body authUserRequest: AuthUserRequest): Call<AuthUserResponse>


    @Headers("Content-Type: application/json")
    @GET("api/messages")
    fun getAllMessages(@Header("X-Branch-Auth-Token") auth_token: String): Call<ArrayList<Message>>

    @Headers("Content-Type: application/json")
    @POST("api/messages")
    fun sendMessage(@Header("X-Branch-Auth-Token") auth_token: String, @Body sendMessageRequest: SendMessageRequest): Call<Message>


}